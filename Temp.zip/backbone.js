var output;
var map;
var killCount; // uniterupted kills, what on should have been, but fuck me. Not butt fuck. No homo
var on; // not even used, but I'm too lazy to remove it and change the calls. Whoops
var totalKills;
var gun;
var headshot;
var inSpawnTrap;
var Usable;
var fps;

// yes, I know constructors probably aren't necessary here, but I do what I want. Go away
function construct(m, o, t, g, h, i, k, f)
{
	output = "We aren't creative enough for that option combo yet. Have a suggestion? Send it to me";
	Usable = "Usable: No";
	map = m;
	killCount = k;
	on = o;
	totalKills = t;
	gun = g;
	headshot = h;
	inSpawnTrap = i;
	fps = f;
	// if you're looking at this code go fuck yourself and just use the site damn it!
	findOutput();
}

function findOutput()
{
	if (map === " " && killCount === " " && totalKills === " " && gun === " " && headshot === " " && inSpawnTrap === " " && fps === " ")
	{
		output = "You can't even enter values? You lazy fuck hole, go back and do it again, this time do it right!";
		Usable = "Usable: Fuck off";
	}
	else if (map === "war" && (totalKills === "9000" || killCount === "9000") && headshot === "yes")
	{
		output = "Well, over 9000 headshots is kind of impressive... But the community says fuck your war so fuck off!";
		Usable = "Usable: No...?";
	}
	else if (map === "war" && (totalKills === "9000" || killCount === "9000"))
	{
		output = "I don't care if you got 1 million kills and they were all one, it's still war. Fuck you!";
		Usable = "Usable: No!";
	}
	else if (fps === "30")
	{
		output = "You broke piece of shit, go buy an El Gato!";
		Usable = "Usable: Never";
	}
	else if (totalKills != killCount)
	{
		output = "You got split. That's all I can say. Get your dick out of your hand and snipe faster next time. Worthless...";
		Usable = "Usable: Depends how garbage your montage already is";
	}
	else if (totalKills === "9000" || killCount === "9000")
	{
		output = "Go back and enter a real kill value you worthless piece of shit!";
		Usable = "Usable: Do something right";
	}
	else if (map === "war")
	{
		output = "Who the fuck would even try and ask if war was acceptable. Litterally unUsable, get the fuck out of here!";
		Usable = "Usable: Literally no";
	}
	else if (gun === "other")
	{
		output = "You're seriously coming here to see if a reg gun is Usable? You're a human garbage can, go fuck your own mother and leave this page now!";
		Usable = "Usable: No";
	}
	else if (inSpawnTrap === "yes" && map === "ardennes")
	{
		output = "You actually came here to check if this was acceptable, get off the bridge you fuck!";
		Usable = "Usable: Depends on your team";
	}
	else if (inSpawnTrap === "yes" && map === "docks")
	{
		output = "You actually came here to check if this was acceptable, get out of little room you fuck!";
		Usable = "Usable: Depends on your team";
	}
	else if (map === "shipment")
	{
		output = "Really? Shipment. The community thinks Shipment is the worst, fuck yourself. Play a real map!";
		Usable = "Usable: Depends on your team, but mainly no. Just make a shipment only tage";
	}
	else if (gun === "karabin")
	{
		output = "You can't even get a feed without a spraying a semi auto. Use a bolt action like a man!";
		Usable = "Usable: If you didn't spray and the feed is solid, then yes.";
	}
	else if ((killCount === "5" || killCount === "6" || killCount === "7" || killCount === "8"  || killCount === "9" || killCount === "10") && inSpawnTrap === "no")
	{
		output = "That's literally all the better you could do? You're garbage, fuck out of here!";
		Usable = "Usable: Sure";
	}
	else if ((killCount === "5" || killCount === "6" || killCount === "7" || killCount === "8"  || killCount === "9" || killCount === "10") && inSpawnTrap === "yes")
	{
		output = "Stop freaking chilling in spawn traps! It doesn't make you good to just watch innocent people spawn. Move around you camping fucker!";
		Usable = "Usable: Really just depends on your team, but most say yes";
	}
}